class Epuletek:
    def __init__(self,nev,varos,magassag,magassag_lab,emeletek_szama,epites_eve):
        self.nev = nev
        self.varos = varos
        self.magassag = float(magassag)
        self.magassag_lab = float(magassag_lab)
        self.emeletek_szama = float(emeletek_szama) #legyen float, mert a félemelet is számíthat, ha van ilyen...
        self.epites_eve = epites_eve

    def magassag_labban(self):
        return round((float(self.magassag) * 3.280839895),2)


def listaba_rak():
    lista = []
    lista_obj = []
    sorok_szama = 0
    while True:
        sor = f.readline()
        if len(sor) == 0 or sorok_szama == 1000: #az állományban max. 1000 épület lehet
            break
        else:
            #a vesszőket ponttá alakítjuk, hogy a str-->float konverzió működjön
            sor = sor.replace(',','.')
            #split --> innentől lista formátumú lesz a sor
            sor = sor.split(';')
            #kitöröljük a felesleges adatokat, és csak a szükséges adatokat hagyjuk meg minden sorban
            del sor[3:-2]
            #print(sor)
            #osztály objektum létrehozása:
            obj = Epuletek(sor[0],sor[1],sor[2],0,sor[3],sor[4])
            obj.magassag_lab = Epuletek.magassag_labban(obj)
            #Ellenőrzés:
            #print(obj.nev.ljust(40), obj.varos.ljust(15), str(obj.magassag).ljust(12), str(obj.magassag_lab).ljust(15), str(obj.emeletek_szama).ljust(15), obj.epites_eve, end='')
            #készítünk egy másik, az összes példányt tartalmazó listát is:
            lista_obj.append(obj)
            #vagy: lista_obj.append(Epuletek(sor[0],sor[1],float(sor[2]),round((float(sor[2]) * 3.280839895),2),float(sor[3]),sor[4]))
            sorok_szama += 1

    #Függvények hívása:
    #***********************
    hany_epulet(lista_obj)
    emeletek_osszege(lista_obj)
    legmagasabb_epulet(lista_obj)
    van_e_epulet('Moszkva',lista_obj)
    hhh_labnal_magasabb(lista_obj)
    v_hhh_magasabb_fajlba(lista_obj)
    epuletek_szama_per_varos(lista_obj)
    v_hhh_magasabb_fajlba(lista_obj)



#3. feladat --> az állományban található épületek száma
def hany_epulet(mylist):
    print('\n\n3. feladat: Épületek száma:', len(mylist), 'db')
    #másik megoldás: for ciklus + számláló (db)



#4. feladat --> összes emelet száma --> ehhez a példányok listáját használom
def emeletek_osszege(mylist):
    em_ossz = 0
    for i in mylist:
        em_ossz += i.emeletek_szama
    print('4. feladat: Emeletek összege:', em_ossz)



#5. feladat --> legmagasabb épület
def legmagasabb_epulet(mylist):
    max = 0
    index = 0
    for i in mylist:
        if i.magassag > max:
            max = i.magassag
            index = i
    print('5. feladat: A legmagasabb épület adatai:')
    print("%-8s %-15s %s" % (' ', 'Név:', index.nev))
    print("%-8s %-15s %s" % (' ', 'Város:', index.varos))
    print("%-8s %-15s %d %s %d %s" % (' ', 'Magasság:', max, 'm /', index.magassag_lab, 'láb'))
    print("%-8s %-15s %d" % (' ', 'Emeletek száma:', index.emeletek_szama))
    print("%-8s %-15s %s" % (' ', 'Építés éve:', index.epites_eve), end='')



#6. feladat --> található-e az állományban moszkvai épület?
def van_e_epulet(varos,mylist):
    talalt = False
    for i in mylist:
        if i.varos == varos:
            talalt = True
            break
    if talalt:
        print('6. feladat:', varos, 'városhoz található épület az adatok között!')
    else:
        print('6. feladat:', varos, 'városhoz nem található épület az adatok között!')



#7. feladat --> a 666 lábnál magasabb épületek száma
def hhh_labnal_magasabb(mylist):
    szamlalo = 0
    for i in mylist:
        if i.magassag_lab > 666:
            szamlalo += 1
    print('7. feladat: A 666 lábnál magasabb épületek száma:', szamlalo)



#8. feladat --> statisztika a város szerinti épületek számáról
def epuletek_szama_per_varos(mylist):
    print('8. feladat: Város statisztika')
    #a városok nevét külön tömbbe mentem, duplikátumtól mentesen:
    varosok = []
    for i in mylist:
        if i.varos not in varosok:
            varosok.append(i.varos)
    #a tömböt felhasználva végigmegyek az összes városnévvel a fpéldányokat tartalmazó listán, és megszámolom előfordulásukat:
    for v in range(len(varosok)):
        szamlalo = 0
        for l in mylist:
            if varosok[v] == l.varos:
                szamlalo += 1
        print("%-8s %-15s %s %s %s" %(' ',varosok[v],':',str(szamlalo).rjust(2),'db'))



#9. feladat --> azon városok neveinek fájlba iratása, ahol 666 lábnál magasabb épület(ek) található(k)
def v_hhh_magasabb_fajlba(mylist):
    print('9. feladat: nmint666.txt')
    #a 666 lábnál magasabb épületeket tartalmazó városok nevét egy külön tömbbe mentem, a duplikátumok szűrésével egyetemben
    hhh = []
    for i in mylist:
        if i.magassag_lab > 666:
            if i.varos not in hhh:
                hhh.append(i.varos)
    #hhh tömb tartalmának fájlba történő kiíratása
    f1 = open('nmint666.txt', 'w')
    for x in range(len(hhh)):
        # print(hhh[x])
        f1.write(hhh[x] + '\n')
    f1.close()



def main():
    # fejlécet készítünk
    #print('Név'.ljust(40), 'Varos'.ljust(15), 'Magassag (m)'.ljust(12), 'Magassag (lab)'.ljust(15), 'Emeletek szama'.ljust(15), 'Epites eve\n')
    listaba_rak()


if __name__ == '__main__':
    f = open('epuletek2.txt', 'r', encoding='utf8')
    main()
    f.close()