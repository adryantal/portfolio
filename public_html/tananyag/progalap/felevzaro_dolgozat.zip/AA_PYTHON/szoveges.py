def szobekeres():
    print('\n1. feladat - Szöveges')
    print('-------------------------')
    sz1 = input('Elso szo: ')
    sz2 = input('Masodik szo: ')
    osszehasonlitas(sz1,sz2)

def osszehasonlitas(szo1,szo2):
    if szo1[len(szo1)-1] == szo2[len(szo2)-1]:
        print('Az utolsó betűk megegyeznek!\n')
    else:
        print('Az utolsó betűk nem egyeznek meg!\n')



