class Elofizetok:
    def __init__(self,sorszam,nev,varos,szul_ev,kiadvany):
        self.sorszam = sorszam
        self.nev = nev
        self.varos = varos
        self.szul_ev = szul_ev
        self.kiadvany = kiadvany


def listaba():
    elofiz_lista = []
    while True:
        sor = f.readline()
        if len(sor) == 0:
            break
        else:
            sor = sor.replace('#',';')
            #print(sor)
            #a sor legutolsó eleméről levesszük a newline-t
            obj = Elofizetok(sor.split(';')[0],sor.split(';')[1],sor.split(';')[2],sor.split(';')[3],sor.split(';')[4].replace('\n',''))
            elofiz_lista.append(obj)

    kiadvanyonkenti_elofiz(elofiz_lista)
    ivicz(elofiz_lista)
    v_bullentin(elofiz_lista)

def kiadvanyonkenti_elofiz(lista):
    kiadvanyok = []
    for i in lista:
        if i.kiadvany not in kiadvanyok:
            kiadvanyok.append(i.kiadvany)
    for j in range(len(kiadvanyok)):
        szamlalo = 0
        for l in lista:
            if kiadvanyok[j] == l.kiadvany:
                szamlalo += 1
        print("%-20s %s %2d %s" %(kiadvanyok[j],':',szamlalo,'db'))

def ivicz(lista):
    for i in lista:
        if i.nev == 'Ivicz Anna':
            print('\n',i.nev,'a(z)',i.kiadvany,'-t rendelte meg.\n')

def v_bullentin(lista):
    #print('\nA Vitorlázó Bullentin magazin előfizetőinek adatai:')
    b_elofizetok = []
    for i in lista:
        if i.kiadvany=='Vitorlázó bulletin' and i.nev not in b_elofizetok:
            b_elofizetok.append([i.nev,i.sorszam,i.varos])

    f1 = open('vitorlazo_bulletin.txt', 'w')
    f1.write('Név'+'\tElőfiz.szám'+'\tVáros'+'\n')
    for j in range(len(b_elofizetok)):
            #print("%10s %-22s %15s %s %-10s %s" % ('Név:',b_elofizetok[j][0],'| Előfiz. szám:',b_elofizetok[j][1],'| Város:',b_elofizetok[j][2]))
            f1.write(b_elofizetok[j][0]+'\t'+b_elofizetok[j][1]+'\t'+b_elofizetok[j][2]+'\n')
    f1.close()


def main():
    print('\n3. feladat - Előfizetők')
    print('-------------------------')
    #f-nek globálisnak kell lennie, hogy ne kapjunk "name undefined" errort
    global f
    f = open('Elofizetok.txt', 'r', encoding='ansi')
    elsosor = f.readline()
    # print('Sorszam'.ljust(8),'Nev'.ljust(15),'Varos'.ljust(10),'Szul.ev'.ljust(8),'Kiadvany\n')
    listaba()
    f.close()



