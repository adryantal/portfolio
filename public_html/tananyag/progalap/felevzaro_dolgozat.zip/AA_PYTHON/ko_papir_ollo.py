import random
import time

def tipp():
    print('\n2. feladat - Kő, papír, olló\n')
    t = ''
    while t not in ['k','p','o']:
        t = input('Válassz: kő(K)   papír(P)    olló (O)\n')
    else:
        return(t.upper())

def jatek():
    t = tipp()
    print('Most én választok...\n')
    time.sleep(2)
    kpo = ['K','P','O']
    kpo_general = random.choice(kpo)
    print('Ezt választottad:', t)
    print('Én ezt választottam:',kpo_general)
    if t == kpo_general:
        print('Ugyanazt tippeltük, egyikünk sem nyert!\n')
    if (t == 'K' and kpo_general == 'O') or (t == 'P' and kpo_general == 'K') or (t == 'O' and kpo_general == 'P'):
        print(t,'>',kpo_general,',tehát Te nyertél!\n')
    if (t == 'O' and kpo_general == 'K') or (t == 'K' and kpo_general == 'P') or (t == 'P' and kpo_general == 'O'):
        print(kpo_general,'>',t,',tehát én nyertem!\n')








