


valaszt = ''
while not valaszt.upper() == 'V':
    print('****** ÜDVÖZLÖM A DOLGOZAT PROGRAMBAN! ******')
    print('(1) Szöveges')
    print('(2) Kő, papír, olló')
    print('(3) Előfizetők')
    print('(V) Program vége\n')
    valaszt = input('Adja meg a választandó feladat számkódját, vagy a program befejezésének betűjelét: ')
    if valaszt.upper() == 'V':
        break
    elif valaszt == '1':
        import szoveges
        szoveges.szobekeres()
    elif valaszt == '2':
        import ko_papir_ollo
        ko_papir_ollo.jatek()
    elif valaszt == '3':
        from elofizetok import *
        main()









